﻿using System;

namespace BaiTapLoiChao
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Console.WriteLine("Welcome to");
             Console.WriteLine("C# 2010 Programming!");
             Console.WriteLine("Programming by your name");
             Console.ReadLine(); */

            Console.WriteLine("{0}\n{1}","Wellcome to","C# 2010 Programming!");
            Console.WriteLine("Programming by your name");
            Console.ReadLine();





        }
    }
}
